<?php
require_once __DIR__ . '/../config.php';
require_once 'templates/header.php';


if (!empty($_SESSION['user'])) {
header('Location: dashboard.php');
exit;
}


// Show login form directly or redirect to login.php
header('Location: login.php');
exit;
