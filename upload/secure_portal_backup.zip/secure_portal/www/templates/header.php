<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function e($s) { return htmlspecialchars($s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
?>
<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secure Portal</title>
<link rel="stylesheet" href="/assets/styles.css">
</head>
<body>
<header>
<h1>Secure Portal</h1>
<?php if (!empty($_SESSION['user'])): ?>
<div>Benvenuto <?php echo e($_SESSION['user']['username']); ?> | <a href="logout.php">Logout</a></div>
<?php endif; ?>
</header>
<main>
