<?php
// download.php
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

// Autenticazione: serve login
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    http_response_code(400);
    exit('ID non valido');
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT original_name, stored_name, mime_type, size_bytes FROM files WHERE id = :id');
    $stmt->execute([':id' => $id]);
    $f = $stmt->fetch();
} catch (Exception $e) {
    http_response_code(500);
    exit('Errore server');
}

if (!$f) {
    http_response_code(404);
    exit('File non trovato');
}

$path = rtrim(STORAGE_PATH, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $f['stored_name'];
if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    exit('File assente.');
}

// Effettua il logging dell'accesso se vuoi (opzionale)
// $logStmt = $pdo->prepare('INSERT INTO downloads_log (file_id, user_id, ip, downloaded_at) VALUES (:fid, :uid, :ip, NOW())');
// $logStmt->execute([':fid'=>$id, ':uid'=>$_SESSION['user']['id'] ?? null, ':ip'=>$_SERVER['REMOTE_ADDR']]);

// Disabilita buffering e impostazioni di output sicure
if (ob_get_level()) {
    ob_end_clean();
}

// Headers sicuri
$basename = basename($f['original_name']);
// rimuovi caratteri pericolosi dalle virgolette
$dispName = str_replace('"', '', $basename);

header('Content-Description: File Transfer');
header('Content-Type: ' . ($f['mime_type'] ?: 'application/octet-stream'));
header('Content-Disposition: attachment; filename="' . $dispName . '"');
header('Content-Length: ' . (int)$f['size_bytes']);
header('Pragma: public');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Expires: 0');

// Invia il file in chunk per evitare memory spike
$fp = fopen($path, 'rb');
if ($fp === false) {
    http_response_code(500);
    exit('Impossibile aprire il file.');
}

while (!feof($fp)) {
    echo fread($fp, 8192);
    // forza l'invio al client
    flush();
}
fclose($fp);
exit;
