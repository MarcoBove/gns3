<?php
require_once __DIR__ . '/../config.php';
require_once 'templates/header.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (empty($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

if (!$_SESSION['user']['is_admin']) {
    http_response_code(403);
    echo "Accesso negato: solo l'amministratore può caricare file.";
    require_once 'templates/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $uploadDir = STORAGE_PATH;
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0750, true);
    }

    $originalName = basename($_FILES['file']['name']);
    $storedName = uniqid('file_', true);
    $targetPath = $uploadDir . '/' . $storedName;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $targetPath)) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

            $stmt = $pdo->prepare("INSERT INTO files (original_name, stored_name, mime_type, size_bytes, uploaded_by) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $originalName,
                $storedName,
                $_FILES['file']['type'],
                $_FILES['file']['size'],
                $_SESSION['user']['id']
            ]);

            echo "<p>✅ File caricato correttamente!</p>";
        } catch (Exception $e) {
            echo "<p>❌ Errore database: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        echo "<p>❌ Errore durante il caricamento del file.</p>";
    }
}
?>

<h2>Carica nuovo file</h2>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <button type="submit">Carica</button>
</form>

<?php
require_once 'templates/footer.php';
?>

