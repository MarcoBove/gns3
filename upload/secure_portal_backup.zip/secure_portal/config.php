<?php
// config.php - conserva questo file fuori dalla root pubblica

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'secure_portal');
define('DB_USER', 'portal_user');
define('DB_PASS', 'PasswordMoltoForte!');    //questa si deve cambiare

// Percorso assoluto alla cartella privata dove salviamo i file (fuori dalla web root)
define('STORAGE_PATH', __DIR__ . '/private_storage');

// Limiti
define('MAX_FILE_SIZE', 50 * 1024 * 1024); // 50 MB

// Estensioni consentite (whitelist)
$ALLOWED_EXTENSIONS = [
  'pdf','zip','docx','xlsx','pptx','txt'
];

// Session hardening
ini_set('session.use_strict_mode', 1);
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
    'httponly' => true,
    'samesite' => 'Lax'
]);

// PDO Connection helper
function get_db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
    }
    return $pdo;
}

