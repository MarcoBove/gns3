CREATE DATABASE IF NOT EXISTS secure_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE secure_portal;


CREATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(100) NOT NULL UNIQUE,
password_hash VARCHAR(255) NOT NULL,
is_admin TINYINT(1) NOT NULL DEFAULT 0,
failed_logins INT NOT NULL DEFAULT 0,
last_failed_login DATETIME NULL,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;


CREATE TABLE files (
id INT AUTO_INCREMENT PRIMARY KEY,
original_name VARCHAR(255) NOT NULL,
stored_name VARCHAR(255) NOT NULL,
mime_type VARCHAR(100) NOT NULL,
size_bytes BIGINT NOT NULL,
uploaded_by INT NULL,
uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;


INSERT INTO users (username, password_hash, is_admin) VALUES
('admin', '{$2y$10$5g5PZzMT84gpEx9JJ/rM6.prx98r1KxDifQvS/p3ps/.06PbFRg6.}', 1);
