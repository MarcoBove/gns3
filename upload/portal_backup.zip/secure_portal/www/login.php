<?php
require_once __DIR__ . '/../config.php';
require_once 'templates/header.php';


$err = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
$err = 'CSRF token mancante o non valido.';
} else {
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';


if ($username === '' || $password === '') {
$err = 'Inserisci username e password.';
} else {
$pdo = get_db();
$stmt = $pdo->prepare('SELECT id, username, password_hash, is_admin, failed_logins, last_failed_login FROM users WHERE username = :u');
$stmt->execute([':u' => $username]);
$user = $stmt->fetch();
if (!$user) {
// generic message
$err = 'Credential not valid.';
} else {
// simple brute-force mitigation: if too many failed attempts, delay
if ($user['failed_logins'] >= 5 && strtotime($user['last_failed_login']) > time() - 900) {
$err = 'Too many requests. Try after some minutes.';
} elseif (password_verify($password, $user['password_hash'])) {
// success
session_regenerate_id(true);
// reset failed logins
$pdo->prepare('UPDATE users SET failed_logins = 0, last_failed_login = NULL WHERE id = :id')->execute([':id' => $user['id']]);
$_SESSION['user'] = [
'id' => $user['id'],
'username' => $user['username'],
'is_admin' => (bool)$user['is_admin']
];
header('Location: dashboard.php');
exit;
} else {
// increment failed
$pdo->prepare('UPDATE users SET failed_logins = failed_logins + 1, last_failed_login = NOW() WHERE id = :id')->execute([':id' => $user['id']]);
$err = 'Credentials not valid.';
}
}
}
}
}


// create CSRF token
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['csrf_token'];
?>


<h2>Login</h2>
<?php if ($err): ?>
<div class="error"><?php echo e($err); ?></div>
<?php endif; ?>
<form method="post" action="login.php">
<input type="hidden" name="csrf_token" value="<?php echo e($csrf); ?>">
<label>Username: <input name="username" required></label><br>
<label>Password: <input type="password" name="password" required></label><br>
<button type="submit">Login</button>
</form>


<?php require 'templates/footer.php'; ?>
