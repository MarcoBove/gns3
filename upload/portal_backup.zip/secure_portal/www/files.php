<?php
// files.php - restituisce JSON con la lista file (solo per utenti autenticati)
require_once __DIR__ . '/../config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthenticated']);
    exit;
}

try {
    $pdo = get_db();
    $stmt = $pdo->query('SELECT id, original_name, size_bytes, uploaded_at FROM files ORDER BY uploaded_at DESC');
    $rows = $stmt->fetchAll();
    // aggiungi campo download_url se vuoi
    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    foreach ($rows as &$r) {
        $r['size_kb'] = round($r['size_bytes'] / 1024, 2);
        $r['download_url'] = $base . '/download.php?id=' . urlencode($r['id']);
    }
    echo json_encode($rows, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Errore server']);
}
